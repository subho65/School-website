<?php
// UTF-8 everywhere
header('Content-Type: text/html; charset=UTF-8');
mb_internal_encoding('UTF-8');
date_default_timezone_set('Asia/Kolkata');

if (session_status() === PHP_SESSION_NONE) {
  session_start();
}

// Database config
define('DB_HOST', '127.0.0.1');
define('DB_USER', 'root');
define('DB_PASS', 'root');
define('DB_NAME', 'school_db');

// Base paths
define('BASE_PATH', rtrim(str_replace('\\', '/', dirname(__DIR__)), '/'));
define('BASE_URL', rtrim((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http') . '://'. $_SERVER['HTTP_HOST'] . rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\'), '/'));

$mysqli = @new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($mysqli->connect_errno) {
  // install.php will create DB/tables
}
if ($mysqli && !$mysqli->connect_errno) {
  $mysqli->set_charset('utf8mb4');
}

// Security helpers
function e($str) { return htmlspecialchars((string)$str, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function random_str($length = 16) { return bin2hex(random_bytes($length)); }

if (empty($_SESSION['csrf'])) {
  $_SESSION['csrf'] = bin2hex(random_bytes(32));
}
function csrf_token() { return $_SESSION['csrf'] ?? ''; }
function verify_csrf() {
  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf']) || !hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'])) {
      http_response_code(403);
      exit('Invalid CSRF token');
    }
  }
}

// Auth
function is_admin() { return !empty($_SESSION['admin_id']); }
function require_admin() { if (!is_admin()) { header('Location: login.php'); exit; } }

// Language
require_once __DIR__ . '/lang.php';

// Settings fetch
function get_settings() {
  global $mysqli;
  $defaults = [
    'school_name' => 'Saraswati Shishu Mandir, Kaligram',
    'logo' => '',
    'email' => '',
    'phone' => '',
    'address' => 'Kaligram, India',
    'map_embed' => ''
  ];
  if (!$mysqli || $mysqli->connect_errno) return $defaults;
  $res = $mysqli->query("SELECT school_name, logo, email, phone, address, map_embed FROM settings LIMIT 1");
  if ($res && $res->num_rows) {
    $row = $res->fetch_assoc();
    return array_merge($defaults, $row);
  }
  return $defaults;
}

// Upload helpers
function ensure_dir($path) { if (!is_dir($path)) { @mkdir($path, 0775, true); } }
function safe_upload($file, $destDir, $allowedExt=['jpg','jpeg','png','pdf','mp4']) {
  ensure_dir($destDir);
  if (!isset($file['error']) || $file['error'] !== UPLOAD_ERR_OK) return [false, 'Upload error'];
  $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
  if (!in_array($ext, $allowedExt)) return [false, 'Invalid file type'];
  $name = time().'_'.random_str(6).'.'.$ext;
  $path = rtrim($destDir,'/').'/'.$name;
  if (!move_uploaded_file($file['tmp_name'], $path)) return [false, 'Failed to move upload'];
  return [true, $name];
}

function is_image_ext($ext) {
  return in_array(strtolower($ext), ['jpg','jpeg','png']);
}

function resize_image_if_needed($srcPath, $maxW=1280, $maxH=1280) {
  $info = @getimagesize($srcPath);
  if (!$info) return;
  [$w, $h, $type] = $info;
  if ($w <= $maxW && $h <= $maxH) return;

  $ratio = min($maxW / $w, $maxH / $h);
  $newW = (int)floor($w * $ratio);
  $newH = (int)floor($h * $ratio);

  switch ($type) {
    case IMAGETYPE_JPEG: $src = imagecreatefromjpeg($srcPath); break;
    case IMAGETYPE_PNG: $src = imagecreatefrompng($srcPath); break;
    default: return;
  }
  $dst = imagecreatetruecolor($newW, $newH);
  imagecopyresampled($dst, $src, 0, 0, 0, 0, $newW, $newH, $w, $h);
  if ($type === IMAGETYPE_JPEG) imagejpeg($dst, $srcPath, 85);
  if ($type === IMAGETYPE_PNG) imagepng($dst, $srcPath, 6);
  imagedestroy($src);
  imagedestroy($dst);
}
