<?php
// Simple i18n (English/Bengali)
if (!isset($_SESSION['lang'])) $_SESSION['lang'] = 'en';
if (isset($_GET['lang']) && in_array($_GET['lang'], ['en','bn'], true)) {
  $_SESSION['lang'] = $_GET['lang'];
}
$lang = $_SESSION['lang'];

$T = [
  'en' => [
    'home' => 'Home',
    'about' => 'About',
    'academics' => 'Academics',
    'admissions' => 'Admissions',
    'notices' => 'Notices',
    'results' => 'Results',
    'gallery' => 'Gallery',
    'teachers' => 'Teachers',
    'contact' => 'Contact',
    'help' => 'Help',
    'welcome' => 'Welcome',
    'quick_links' => 'Quick Links',
    'latest_notices' => 'Latest Notices',
    'upcoming_events' => 'Upcoming Events',
    'view_all' => 'View All',
    'download' => 'Download',
    'admission_form' => 'Admission Form',
    'apply_online' => 'Apply Online',
    'roll_no' => 'Roll No.',
    'dob' => 'Date of Birth',
    'search' => 'Search',
    'no_results' => 'No results found.',
    'teachers_directory' => 'Teachers Directory',
    'send_message' => 'Send Message',
    'name' => 'Name',
    'email' => 'Email',
    'phone' => 'Phone',
    'message' => 'Message',
    'submit' => 'Submit',
    'address' => 'Address',
    'language' => 'Language',
    'english' => 'English',
    'bengali' => 'Bengali',
    'news_notices' => 'News & Notices',
  ],
  'bn' => [
    'home' => 'হোম',
    'about' => 'সম্পর্কে',
    'academics' => 'শিক্ষা',
    'admissions' => 'ভর্তি',
    'notices' => 'নোটিস',
    'results' => 'ফলাফল',
    'gallery' => 'গ্যালারি',
    'teachers' => 'শিক্ষকমণ্ডলী',
    'contact' => 'যোগাযোগ',
    'help' => 'সাহায্য',
    'welcome' => 'স্বাগতম',
    'quick_links' => 'দ্রুত লিঙ্ক',
    'latest_notices' => 'সর্বশেষ নোটিস',
    'upcoming_events' => 'আসন্ন অনুষ্ঠান',
    'view_all' => 'সব দেখুন',
    'download' => 'ডাউনলোড',
    'admission_form' => 'ভর্তি ফর্ম',
    'apply_online' => 'অনলাইনে আবেদন',
    'roll_no' => 'রোল নং',
    'dob' => 'জন্ম তারিখ',
    'search' => 'খুঁজুন',
    'no_results' => 'কোন ফলাফল পাওয়া যায়নি।',
    'teachers_directory' => 'শিক্ষক তালিকা',
    'send_message' => 'বার্তা পাঠান',
    'name' => 'নাম',
    'email' => 'ইমেইল',
    'phone' => 'ফোন',
    'message' => 'বার্তা',
    'submit' => 'জমা দিন',
    'address' => 'ঠিকানা',
    'language' => 'ভাষা',
    'english' => 'ইংরেজি',
    'bengali' => 'বাংলা',
    'news_notices' => 'খবর ও নোটিস',
  ]
];

function __t($key) {
  global $T, $lang;
  return $T[$lang][$key] ?? $key;
}
