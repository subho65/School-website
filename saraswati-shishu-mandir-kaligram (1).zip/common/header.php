<?php
require_once __DIR__ . '/config.php';
$S = get_settings();
?>
<!DOCTYPE html>
<html lang="<?php echo e($_SESSION['lang'] ?? 'en'); ?>">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
  <title><?php echo e($S['school_name']); ?></title>
  <meta name="theme-color" content="#0F172A">
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            brand: '#F97316',
            navy: '#0F172A',
            slate: '#64748B'
          }
        }
      }
    }
  </script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    html, body { -webkit-text-size-adjust: 100%; }
    body { font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, "Noto Sans", Ubuntu, "Helvetica Neue", Arial; }
    /* Disable selection & context menu */
    * { -webkit-touch-callout: none; -webkit-user-select: none; -moz-user-select: none; user-select: none; }
    img { pointer-events: none; }
  </style>
  <script>
    // Disable right-click, selection, pinch-zoom
    document.addEventListener('contextmenu', e => e.preventDefault());
    document.addEventListener('selectstart', e => e.preventDefault());
    document.addEventListener('copy', e => e.preventDefault());
    document.addEventListener('gesturestart', e => e.preventDefault());
    document.addEventListener('keydown', e => {
      if ((e.ctrlKey || e.metaKey) && ['s','u','p','+','=','-','0','c','x'].includes(e.key.toLowerCase())) e.preventDefault();
      if (e.key === 'F12') e.preventDefault();
    });
  </script>
</head>
<body class="bg-white text-slate antialiased">
  <header class="bg-navy text-white">
    <div class="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
      <a href="index.php" class="flex items-center gap-3 min-w-0 flex-1">
        <?php if (!empty($S['logo'])): ?>
          <img src="<?php echo e('uploads/'.basename($S['logo'])); ?>" alt="Logo" class="h-10 w-10 rounded object-cover shrink-0">
        <?php else: ?>
          <div class="h-10 w-10 rounded bg-brand flex items-center justify-center font-bold">S</div>
        <?php endif; ?>
        <div class="text-pretty truncate">
          <div class="text-sm opacity-80">Saraswati Shishu Mandir</div>
          <div class="text-base font-semibold">Kaligram</div>
        </div>
      </a>
      <button id="navToggle" aria-label="Toggle Menu" aria-controls="mobileNav" aria-expanded="false" class="md:hidden p-2 rounded bg-brand text-white shrink-0 ml-2">
        <i class="fa fa-bars"></i>
      </button>
      <nav id="mainNav" class="hidden md:flex items-center gap-4">
        <a class="px-3 py-2 rounded hover:bg-white/10" href="index.php"><?php echo e(__t('home')); ?></a>
        <a class="px-3 py-2 rounded hover:bg-white/10" href="about.php"><?php echo e(__t('about')); ?></a>
        <a class="px-3 py-2 rounded hover:bg-white/10" href="academics.php"><?php echo e(__t('academics')); ?></a>
        <a class="px-3 py-2 rounded hover:bg-white/10" href="admissions.php"><?php echo e(__t('admissions')); ?></a>
        <a class="px-3 py-2 rounded hover:bg-white/10" href="notices.php"><?php echo e(__t('notices')); ?></a>
        <a class="px-3 py-2 rounded hover:bg-white/10" href="results.php"><?php echo e(__t('results')); ?></a>
        <a class="px-3 py-2 rounded hover:bg-white/10" href="gallery.php"><?php echo e(__t('gallery')); ?></a>
        <a class="px-3 py-2 rounded hover:bg-white/10" href="teachers.php"><?php echo e(__t('teachers')); ?></a>
        <a class="px-3 py-2 rounded hover:bg-white/10" href="contact.php"><?php echo e(__t('contact')); ?></a>
        <a class="px-3 py-2 rounded hover:bg-white/10" href="help.php"><?php echo e(__t('help')); ?></a>
        <div class="pl-2">
          <div class="flex items-center gap-2">
            <span class="text-xs opacity-80"><?php echo e(__t('language')); ?>:</span>
            <a class="px-2 py-1 rounded bg-white/10" href="?lang=en"><?php echo e(__t('english')); ?></a>
            <a class="px-2 py-1 rounded bg-white/10" href="?lang=bn"><?php echo e(__t('bengali')); ?></a>
          </div>
        </div>
      </nav>
    </div>
    <div id="mobileNav" class="md:hidden hidden px-4 pb-3">
      <div class="grid grid-cols-2 gap-2">
        <a class="px-3 py-2 rounded bg-white/10" href="index.php"><?php echo e(__t('home')); ?></a>
        <a class="px-3 py-2 rounded bg-white/10" href="about.php"><?php echo e(__t('about')); ?></a>
        <a class="px-3 py-2 rounded bg-white/10" href="academics.php"><?php echo e(__t('academics')); ?></a>
        <a class="px-3 py-2 rounded bg-white/10" href="admissions.php"><?php echo e(__t('admissions')); ?></a>
        <a class="px-3 py-2 rounded bg-white/10" href="notices.php"><?php echo e(__t('notices')); ?></a>
        <a class="px-3 py-2 rounded bg-white/10" href="results.php"><?php echo e(__t('results')); ?></a>
        <a class="px-3 py-2 rounded bg-white/10" href="gallery.php"><?php echo e(__t('gallery')); ?></a>
        <a class="px-3 py-2 rounded bg-white/10" href="teachers.php"><?php echo e(__t('teachers')); ?></a>
        <a class="px-3 py-2 rounded bg-white/10" href="contact.php"><?php echo e(__t('contact')); ?></a>
        <a class="px-3 py-2 rounded bg-white/10" href="help.php"><?php echo e(__t('help')); ?></a>
      </div>
    </div>
  </header>
  <script>
    const navToggle = document.getElementById('navToggle');
    const mobileNav = document.getElementById('mobileNav');
    const mainNav = document.getElementById('mainNav');
    if (navToggle) {
      navToggle.addEventListener('click', () => {
        const isHidden = mobileNav.classList.toggle('hidden');
        navToggle.setAttribute('aria-expanded', isHidden ? 'false' : 'true');
      });
      window.addEventListener('resize', () => {
        if (window.innerWidth >= 768) {
          mobileNav.classList.add('hidden');
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    }
  </script>
