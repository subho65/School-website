<?php $S = get_settings(); ?>
  <footer class="bg-navy text-white mt-10">
    <div class="max-w-6xl mx-auto px-4 py-8 grid gap-6 md:grid-cols-3">
      <div>
        <h3 class="font-semibold mb-2">Contact</h3>
        <p class="text-sm"><?php echo e(__t('address')); ?>: <?php echo e($S['address']); ?></p>
        <p class="text-sm">Email: <?php echo e($S['email']); ?></p>
        <p class="text-sm">Phone: <?php echo e($S['phone']); ?></p>
      </div>
      <div>
        <h3 class="font-semibold mb-2"><?php echo e(__t('quick_links')); ?></h3>
        <ul class="text-sm space-y-1">
          <li><a class="hover:underline" href="admissions.php"><?php echo e(__t('admissions')); ?></a></li>
          <li><a class="hover:underline" href="results.php"><?php echo e(__t('results')); ?></a></li>
          <li><a class="hover:underline" href="notices.php"><?php echo e(__t('notices')); ?></a></li>
          <li><a class="hover:underline" href="gallery.php"><?php echo e(__t('gallery')); ?></a></li>
        </ul>
      </div>
      <div>
        <h3 class="font-semibold mb-2">Follow</h3>
        <div class="flex gap-3 text-xl">
          <a aria-label="Facebook" href="#" class="hover:text-brand"><i class="fab fa-facebook"></i></a>
          <a aria-label="YouTube" href="#" class="hover:text-brand"><i class="fab fa-youtube"></i></a>
        </div>
      </div>
    </div>
    <div class="text-center text-xs py-3 border-t border-white/10">
      &copy; <?php echo date('Y'); ?> <?php echo e($S['school_name']); ?>. All rights reserved.
    </div>
  </footer>
</body>
</html>
