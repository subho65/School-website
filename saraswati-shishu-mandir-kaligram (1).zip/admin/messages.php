<?php include __DIR__.'/common/header.php'; verify_csrf(); ?>
<?php
$msg = '';
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['delete_id'])) {
  $id = (int)$_POST['delete_id'];
  $st = $mysqli->prepare("DELETE FROM contact_messages WHERE id=?");
  $st->bind_param('i',$id); $st->execute(); $st->close();
  $msg='Message deleted.';
}
$rows = $mysqli->query("SELECT id, name, email, phone, message, ip, created_at FROM contact_messages ORDER BY id DESC LIMIT 500");
?>
<div class="max-w-5xl">
  <h2 class="text-lg font-semibold mb-3">Messages</h2>
  <?php if ($msg): ?><div class="mb-3 p-2 bg-green-50 border border-green-200 text-green-800 rounded"><?php echo e($msg); ?></div><?php endif; ?>
  <div class="bg-white border border-slate/20 rounded overflow-x-auto">
    <table class="min-w-full text-sm">
      <thead>
        <tr class="bg-slate/10">
          <th class="text-left p-2">Name</th>
          <th class="text-left p-2">Email</th>
          <th class="text-left p-2">Phone</th>
          <th class="text-left p-2">Message</th>
          <th class="text-left p-2">IP</th>
          <th class="text-left p-2">Date</th>
          <th class="text-left p-2">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($rows && $rows->num_rows): while ($m = $rows->fetch_assoc()): ?>
          <tr class="border-t align-top">
            <td class="p-2"><?php echo e($m['name']); ?></td>
            <td class="p-2"><?php echo e($m['email']); ?></td>
            <td class="p-2"><?php echo e($m['phone']); ?></td>
            <td class="p-2 max-w-[360px]"><?php echo nl2br(e($m['message'])); ?></td>
            <td class="p-2"><?php echo e($m['ip']); ?></td>
            <td class="p-2"><?php echo e($m['created_at']); ?></td>
            <td class="p-2">
              <form method="post" onsubmit="return confirm('Delete this message?')">
                <input type="hidden" name="csrf" value="<?php echo e(csrf_token()); ?>">
                <input type="hidden" name="delete_id" value="<?php echo (int)$m['id']; ?>">
                <button class="px-2 py-1 text-xs rounded bg-red-600 text-white">Delete</button>
              </form>
            </td>
          </tr>
        <?php endwhile; else: ?>
          <tr><td class="p-3 text-sm" colspan="7">No messages yet.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php include __DIR__.'/common/footer.php'; ?>
