<?php include __DIR__.'/common/header.php'; verify_csrf(); ?>
<?php
$msg='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $title = trim($_POST['title'] ?? '');
  $date = $_POST['date'] ?? '';
  $desc = trim($_POST['description'] ?? '');
  $st=$mysqli->prepare("INSERT INTO events (title, date, description, created_at) VALUES (?,?,?,NOW())");
  $st->bind_param('sss',$title,$date,$desc); $st->execute(); $st->close();
  $msg='Event added.';
}
if (isset($_GET['del'])) { $id=(int)$_GET['del']; $mysqli->query("DELETE FROM events WHERE id={$id}"); header('Location: events.php'); exit; }
$rows=$mysqli->query("SELECT * FROM events ORDER BY date DESC");
?>
<div class="max-w-3xl">
  <h2 class="text-lg font-semibold mb-3">Manage Events</h2>
  <?php if ($msg): ?><div class="mb-3 p-2 bg-green-50 border border-green-200 text-green-800 rounded"><?php echo e($msg); ?></div><?php endif; ?>
  <form method="post" class="bg-white border border-slate/20 rounded p-4 space-y-3">
    <input type="hidden" name="csrf" value="<?php echo e(csrf_token()); ?>">
    <input name="title" placeholder="Title" required class="w-full border rounded px-3 py-2" />
    <input type="date" name="date" required class="w-full border rounded px-3 py-2" />
    <textarea name="description" placeholder="Description" class="w-full border rounded px-3 py-2 h-24"></textarea>
    <button class="px-4 py-2 bg-brand text-white rounded">Add Event</button>
  </form>

  <div class="mt-6 bg-white border border-slate/20 rounded divide-y">
    <?php while ($e = $rows->fetch_assoc()): ?>
      <div class="p-3 flex items-center justify-between">
        <div>
          <div class="font-medium"><?php echo e($e['title']); ?></div>
          <div class="text-xs opacity-70"><?php echo e($e['date']); ?></div>
        </div>
        <a class="text-sm text-red-600" href="?del=<?php echo (int)$e['id']; ?>" onclick="return confirm('Delete?')">Delete</a>
      </div>
    <?php endwhile; ?>
  </div>
</div>
<?php include __DIR__.'/common/footer.php'; ?>
