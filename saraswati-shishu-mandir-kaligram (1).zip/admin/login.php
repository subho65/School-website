<?php
require_once __DIR__.'/../common/config.php';
if (is_admin()) { header('Location: index.php'); exit; }
verify_csrf();

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $username = trim($_POST['username'] ?? '');
  $password = $_POST['password'] ?? '';
  if ($mysqli && !$mysqli->connect_errno) {
    $st = $mysqli->prepare("SELECT id, password FROM admin WHERE username = ? LIMIT 1");
    $st->bind_param('s', $username);
    $st->execute(); $st->bind_result($id, $hash);
    if ($st->fetch() && password_verify($password, $hash)) {
      $_SESSION['admin_id'] = $id;
      header('Location: index.php'); exit;
    } else {
      $msg = 'Invalid credentials';
    }
    $st->close();
  } else {
    $msg = 'Database not available.';
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Login</title>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen bg-slate/10 flex items-center justify-center p-4">
  <form method="post" class="bg-white border border-slate/20 rounded p-6 w-full max-w-sm space-y-3">
    <h1 class="text-lg font-semibold text-center">Admin Login</h1>
    <?php if ($msg): ?><div class="p-2 text-sm bg-red-50 text-red-700 border border-red-200 rounded"><?php echo e($msg); ?></div><?php endif; ?>
    <input type="hidden" name="csrf" value="<?php echo e(csrf_token()); ?>">
    <div>
      <label class="block text-sm mb-1">Username</label>
      <input name="username" required class="w-full border rounded px-3 py-2" />
    </div>
    <div>
      <label class="block text-sm mb-1">Password</label>
      <input name="password" type="password" required class="w-full border rounded px-3 py-2" />
    </div>
    <button class="w-full px-4 py-2 bg-brand text-white rounded">Login</button>
  </form>
</body>
</html>
