<?php include __DIR__.'/common/header.php'; verify_csrf(); ?>
<?php
$msg='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $name = trim($_POST['school_name'] ?? '');
  $email = trim($_POST['email'] ?? '');
  $phone = trim($_POST['phone'] ?? '');
  $address = trim($_POST['address'] ?? '');
  $map_embed = trim($_POST['map_embed'] ?? '');
  $logo = '';
  if (!empty($_FILES['logo']['name'])) {
    [$ok,$res] = safe_upload($_FILES['logo'], BASE_PATH.'/uploads', ['jpg','jpeg','png']);
    if ($ok) { $logo = 'uploads/'.$res; resize_image_if_needed(BASE_PATH.'/'.$logo, 512, 512); } else { $msg = $res; }
  }
  if (!$msg) {
    // Upsert logic
    $r = $mysqli->query("SELECT id FROM settings LIMIT 1");
    if ($r && $r->num_rows) {
      if ($logo) {
        $st = $mysqli->prepare("UPDATE settings SET school_name=?, logo=?, email=?, phone=?, address=?, map_embed=? WHERE id=1");
        $st->bind_param('ssssss',$name,$logo,$email,$phone,$address,$map_embed);
      } else {
        $st = $mysqli->prepare("UPDATE settings SET school_name=?, email=?, phone=?, address=?, map_embed=? WHERE id=1");
        $st->bind_param('sssss',$name,$email,$phone,$address,$map_embed);
      }
      $st->execute(); $st->close();
    } else {
      $st = $mysqli->prepare("INSERT INTO settings (school_name, logo, email, phone, address, map_embed) VALUES (?,?,?,?,?,?)");
      $st->bind_param('ssssss',$name,$logo,$email,$phone,$address,$map_embed); $st->execute(); $st->close();
    }
    $msg='Settings saved.';
  }
}
$S = get_settings();
?>
<div class="max-w-3xl">
  <h2 class="text-lg font-semibold mb-3">Settings</h2>
  <?php if ($msg): ?><div class="mb-3 p-2 bg-green-50 border border-green-200 text-green-800 rounded"><?php echo e($msg); ?></div><?php endif; ?>
  <form method="post" enctype="multipart/form-data" class="bg-white border border-slate/20 rounded p-4 space-y-3">
    <input type="hidden" name="csrf" value="<?php echo e(csrf_token()); ?>">
    <div>
      <label class="block text-sm mb-1">School Name</label>
      <input name="school_name" value="<?php echo e($S['school_name']); ?>" class="w-full border rounded px-3 py-2" />
    </div>
    <div>
      <label class="block text-sm mb-1">Email</label>
      <input name="email" value="<?php echo e($S['email']); ?>" class="w-full border rounded px-3 py-2" />
    </div>
    <div>
      <label class="block text-sm mb-1">Phone</label>
      <input name="phone" value="<?php echo e($S['phone']); ?>" class="w-full border rounded px-3 py-2" />
    </div>
    <div>
      <label class="block text-sm mb-1">Address</label>
      <input name="address" value="<?php echo e($S['address']); ?>" class="w-full border rounded px-3 py-2" />
    </div>
    <div>
      <label class="block text-sm mb-1">Google Map Embed (iframe)</label>
      <textarea name="map_embed" class="w-full border rounded px-3 py-2 h-24"><?php echo e($S['map_embed']); ?></textarea>
    </div>
    <div>
      <label class="block text-sm mb-1">Logo</label>
      <input type="file" name="logo" accept=".jpg,.jpeg,.png" />
    </div>
    <button class="px-4 py-2 bg-brand text-white rounded">Save</button>
  </form>
</div>
<?php include __DIR__.'/common/footer.php'; ?>
