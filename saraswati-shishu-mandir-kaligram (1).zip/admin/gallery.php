<?php include __DIR__.'/common/header.php'; verify_csrf(); ?>
<?php
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $type = $_POST['type'] ?? 'image';
  if ($type === 'image') {
    [$ok, $res] = safe_upload($_FILES['media'], BASE_PATH.'/uploads/gallery', ['jpg','jpeg','png']);
    if ($ok) {
      $path = BASE_PATH.'/uploads/gallery/'.$res;
      resize_image_if_needed($path);
      $st = $mysqli->prepare("INSERT INTO gallery (image, type, created_at) VALUES (?, 'image', NOW())");
      $st->bind_param('s', $res); $st->execute(); $st->close();
      $msg = 'Image uploaded.';
    } else { $msg = $res; }
  } else {
    [$ok, $res] = safe_upload($_FILES['media'], BASE_PATH.'/uploads/gallery', ['mp4']);
    if ($ok) {
      $st = $mysqli->prepare("INSERT INTO gallery (image, type, created_at) VALUES (?, 'video', NOW())");
      $st->bind_param('s', $res); $st->execute(); $st->close();
      $msg = 'Video uploaded.';
    } else { $msg = $res; }
  }
}
if (isset($_GET['del'])) {
  $id = (int)$_GET['del'];
  $st = $mysqli->prepare("SELECT image FROM gallery WHERE id=?");
  $st->bind_param('i',$id); $st->execute(); $st->bind_result($f);
  if ($st->fetch() && $f) { @unlink(BASE_PATH.'/uploads/gallery/'.$f); }
  $st->close();
  $mysqli->query("DELETE FROM gallery WHERE id={$id}");
  header('Location: gallery.php'); exit;
}
$rows = $mysqli->query("SELECT id, image, type, created_at FROM gallery ORDER BY created_at DESC");
?>
<div class="max-w-4xl">
  <h2 class="text-lg font-semibold mb-3">Manage Gallery</h2>
  <?php if ($msg): ?><div class="mb-3 p-2 bg-green-50 border border-green-200 text-green-800 rounded"><?php echo e($msg); ?></div><?php endif; ?>
  <form method="post" enctype="multipart/form-data" class="bg-white border border-slate/20 rounded p-4 space-y-3">
    <input type="hidden" name="csrf" value="<?php echo e(csrf_token()); ?>">
    <div>
      <label class="block text-sm mb-1">Type</label>
      <select name="type" class="border rounded px-3 py-2">
        <option value="image">Image</option>
        <option value="video">Video (MP4)</option>
      </select>
    </div>
    <div>
      <label class="block text-sm mb-1">Media</label>
      <input type="file" name="media" accept=".jpg,.jpeg,.png,.mp4" required />
    </div>
    <button class="px-4 py-2 bg-brand text-white rounded">Upload</button>
  </form>

  <div class="mt-6 grid grid-cols-2 md:grid-cols-4 gap-3">
    <?php while ($g = $rows->fetch_assoc()): ?>
      <div class="bg-white border border-slate/20 rounded overflow-hidden">
        <?php if ($g['type']==='image'): ?>
          <img src="<?php echo '../uploads/gallery/'.e($g['image']); ?>" class="w-full aspect-square object-cover" />
        <?php else: ?>
          <video src="<?php echo '../uploads/gallery/'.e($g['image']); ?>" class="w-full aspect-square object-cover" controls></video>
        <?php endif; ?>
        <div class="p-2 text-right">
          <a class="text-xs text-red-600" href="?del=<?php echo (int)$g['id']; ?>" onclick="return confirm('Delete?')">Delete</a>
        </div>
      </div>
    <?php endwhile; ?>
  </div>
</div>
<?php include __DIR__.'/common/footer.php'; ?>
