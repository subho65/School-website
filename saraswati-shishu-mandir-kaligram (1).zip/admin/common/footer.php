<footer class="mt-8 text-xs text-slate">Admin Panel</footer>
    </main>
  </div>
</body>
</html>
