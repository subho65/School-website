<?php $nav = basename($_SERVER['PHP_SELF']); ?>
<aside class="bg-navy text-white p-4">
  <div class="font-semibold mb-4">Admin Panel</div>
  <nav class="space-y-2 text-sm">
    <a class="block px-2 py-1 rounded <?php echo $nav==='index.php'?'bg-white/10':''; ?>" href="index.php"><i class="fa fa-gauge mr-2"></i>Dashboard</a>
    <a class="block px-2 py-1 rounded <?php echo $nav==='banner.php'?'bg-white/10':''; ?>" href="banner.php"><i class="fa fa-image mr-2"></i>Banners</a>
    <a class="block px-2 py-1 rounded <?php echo $nav==='notice.php'?'bg-white/10':''; ?>" href="notice.php"><i class="fa fa-bullhorn mr-2"></i>Notices</a>
    <a class="block px-2 py-1 rounded <?php echo $nav==='gallery.php'?'bg-white/10':''; ?>" href="gallery.php"><i class="fa fa-images mr-2"></i>Gallery</a>
    <a class="block px-2 py-1 rounded <?php echo $nav==='teachers.php'?'bg-white/10':''; ?>" href="teachers.php"><i class="fa fa-user-tie mr-2"></i>Teachers</a>
    <a class="block px-2 py-1 rounded <?php echo $nav==='students.php'?'bg-white/10':''; ?>" href="students.php"><i class="fa fa-users mr-2"></i>Students</a>
    <a class="block px-2 py-1 rounded <?php echo $nav==='admissions.php'?'bg-white/10':''; ?>" href="admissions.php"><i class="fa fa-user-plus mr-2"></i>Admissions</a>
    <a class="block px-2 py-1 rounded <?php echo $nav==='results.php'?'bg-white/10':''; ?>" href="results.php"><i class="fa fa-file-import mr-2"></i>Results</a>
    <a class="block px-2 py-1 rounded <?php echo $nav==='events.php'?'bg-white/10':''; ?>" href="events.php"><i class="fa fa-calendar mr-2"></i>Events</a>
    <a class="block px-2 py-1 rounded <?php echo $nav==='settings.php'?'bg-white/10':''; ?>" href="settings.php"><i class="fa fa-gear mr-2"></i>Settings</a>
    <a class="block px-2 py-1 rounded <?php echo $nav==='messages.php'?'bg-white/10':''; ?>" href="messages.php"><i class="fa fa-envelope-open-text mr-2"></i>Messages</a>
  </nav>
</aside>
