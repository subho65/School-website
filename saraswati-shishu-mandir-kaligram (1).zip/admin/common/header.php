<?php
require_once __DIR__.'/../../common/config.php';
require_admin();
$S = get_settings();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin - <?php echo e($S['school_name']); ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = { theme: { extend: { colors: { brand: '#F97316', navy: '#0F172A', slate: '#64748B' }}}}
  </script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="bg-slate/10">
  <div class="min-h-screen grid md:grid-cols-[220px_1fr]">
    <?php include __DIR__.'/sidebar.php'; ?>
    <main class="p-4">
      <header class="flex items-center justify-between mb-4">
        <h1 class="font-semibold">Dashboard</h1>
        <div class="flex items-center gap-3">
          <a href="../index.php" class="text-sm text-brand" target="_blank">View Site</a>
          <a href="logout.php" class="text-sm text-red-600">Logout</a>
        </div>
      </header>
