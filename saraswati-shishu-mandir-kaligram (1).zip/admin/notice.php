<?php include __DIR__.'/common/header.php'; verify_csrf(); ?>
<?php
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $title = trim($_POST['title'] ?? '');
  $description = trim($_POST['description'] ?? '');
  $fileName = '';
  if (!empty($_FILES['file']['name'])) {
    [$ok, $res] = safe_upload($_FILES['file'], BASE_PATH.'/uploads/notices', ['pdf','jpg','jpeg','png']);
    if ($ok) { $fileName = $res; } else { $msg = $res; }
  }
  if (!$msg) {
    $st = $mysqli->prepare("INSERT INTO notices (title, description, file, created_at) VALUES (?,?,?,NOW())");
    $st->bind_param('sss', $title, $description, $fileName);
    $st->execute(); $st->close();
    $msg = 'Notice added.';
  }
}
if (isset($_GET['del'])) {
  $id = (int)$_GET['del'];
  $st = $mysqli->prepare("SELECT file FROM notices WHERE id=?");
  $st->bind_param('i',$id); $st->execute(); $st->bind_result($f); if ($st->fetch() && $f) { @unlink(BASE_PATH.'/uploads/notices/'.$f); }
  $st->close();
  $mysqli->query("DELETE FROM notices WHERE id={$id}");
  header('Location: notice.php'); exit;
}
$rows = $mysqli->query("SELECT id, title, file, created_at FROM notices ORDER BY created_at DESC");
?>
<div class="max-w-3xl">
  <h2 class="text-lg font-semibold mb-3">Manage Notices</h2>
  <?php if ($msg): ?><div class="mb-3 p-2 bg-green-50 border border-green-200 text-green-800 rounded"><?php echo e($msg); ?></div><?php endif; ?>
  <form method="post" enctype="multipart/form-data" class="bg-white border border-slate/20 rounded p-4 space-y-3">
    <input type="hidden" name="csrf" value="<?php echo e(csrf_token()); ?>">
    <div>
      <label class="block text-sm mb-1">Title</label>
      <input name="title" required class="w-full border rounded px-3 py-2" />
    </div>
    <div>
      <label class="block text-sm mb-1">Description</label>
      <textarea name="description" class="w-full border rounded px-3 py-2 h-24"></textarea>
    </div>
    <div>
      <label class="block text-sm mb-1">File (optional)</label>
      <input type="file" name="file" accept=".pdf,.jpg,.jpeg,.png" />
    </div>
    <button class="px-4 py-2 bg-brand text-white rounded">Add Notice</button>
  </form>

  <div class="mt-6 bg-white border border-slate/20 rounded divide-y">
    <?php while ($n = $rows->fetch_assoc()): ?>
      <div class="p-3 flex items-center justify-between">
        <div>
          <div class="font-medium"><?php echo e($n['title']); ?></div>
          <div class="text-xs opacity-60"><?php echo e(date('d M Y', strtotime($n['created_at']))); ?></div>
        </div>
        <div class="flex items-center gap-3">
          <?php if (!empty($n['file'])): ?><a class="text-sm text-brand" href="../download.php?type=notice&id=<?php echo (int)$n['id']; ?>" target="_blank">Download</a><?php endif; ?>
          <a class="text-sm text-red-600" href="?del=<?php echo (int)$n['id']; ?>" onclick="return confirm('Delete?')">Delete</a>
        </div>
      </div>
    <?php endwhile; ?>
  </div>
</div>
<?php include __DIR__.'/common/footer.php'; ?>
