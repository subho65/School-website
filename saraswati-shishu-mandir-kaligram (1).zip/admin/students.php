<?php include __DIR__.'/common/header.php'; verify_csrf(); ?>
<?php
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $name = trim($_POST['name'] ?? '');
  $class = trim($_POST['class'] ?? '');
  $roll = trim($_POST['roll_no'] ?? '');
  $dob = $_POST['dob'] ?? '';
  $email = trim($_POST['email'] ?? '');
  $phone = trim($_POST['phone'] ?? '');
  $address = trim($_POST['address'] ?? '');
  $st = $mysqli->prepare("INSERT INTO students (name, class, roll_no, dob, email, phone, address, created_at) VALUES (?,?,?,?,?,?,?,NOW())");
  $st->bind_param('sssssss',$name,$class,$roll,$dob,$email,$phone,$address);
  if ($st->execute()) $msg='Student added.'; else $msg='Failed.';
  $st->close();
}
if (isset($_GET['del'])) {
  $id = (int)$_GET['del'];
  $mysqli->query("DELETE FROM students WHERE id={$id}");
  header('Location: students.php'); exit;
}
$rows = $mysqli->query("SELECT id, name, class, roll_no FROM students ORDER BY created_at DESC LIMIT 100");
?>
<div class="max-w-4xl">
  <h2 class="text-lg font-semibold mb-3">Manage Students</h2>
  <?php if ($msg): ?><div class="mb-3 p-2 bg-green-50 border border-green-200 text-green-800 rounded"><?php echo e($msg); ?></div><?php endif; ?>
  <form method="post" class="bg-white border border-slate/20 rounded p-4 grid md:grid-cols-3 gap-3">
    <input type="hidden" name="csrf" value="<?php echo e(csrf_token()); ?>">
    <input name="name" placeholder="Name" required class="border rounded px-3 py-2" />
    <input name="class" placeholder="Class" required class="border rounded px-3 py-2" />
    <input name="roll_no" placeholder="Roll No" required class="border rounded px-3 py-2" />
    <input type="date" name="dob" required class="border rounded px-3 py-2" />
    <input type="email" name="email" placeholder="Email" class="border rounded px-3 py-2" />
    <input name="phone" placeholder="Phone" class="border rounded px-3 py-2" />
    <input name="address" placeholder="Address" class="md:col-span-3 border rounded px-3 py-2" />
    <button class="px-4 py-2 bg-brand text-white rounded md:col-span-3">Add Student</button>
  </form>

  <div class="mt-6 bg-white border border-slate/20 rounded divide-y">
    <?php while ($s = $rows->fetch_assoc()): ?>
      <div class="p-3 flex items-center justify-between">
        <div><div class="font-medium"><?php echo e($s['name']); ?></div><div class="text-xs opacity-70">Class <?php echo e($s['class']); ?> • Roll <?php echo e($s['roll_no']); ?></div></div>
        <a class="text-sm text-red-600" href="?del=<?php echo (int)$s['id']; ?>" onclick="return confirm('Delete?')">Delete</a>
      </div>
    <?php endwhile; ?>
  </div>
</div>
<?php include __DIR__.'/common/footer.php'; ?>
