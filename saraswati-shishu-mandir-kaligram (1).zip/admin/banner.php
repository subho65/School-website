<?php include __DIR__.'/common/header.php'; verify_csrf(); ?>
<?php
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['image'])) {
  [$ok, $res] = safe_upload($_FILES['image'], BASE_PATH.'/uploads/banners', ['jpg','jpeg','png']);
  if ($ok) {
    $imgName = 'banners/'.$res;
    $path = BASE_PATH.'/uploads/'.$imgName;
    resize_image_if_needed($path);
    $link = trim($_POST['link'] ?? '');
    $st = $mysqli->prepare("INSERT INTO banners (image, link) VALUES (?, ?)");
    $st->bind_param('ss', $imgName, $link);
    $st->execute(); $st->close();
    $msg = 'Banner added.';
  } else { $msg = $res; }
}
if (isset($_GET['del'])) {
  $id = (int)$_GET['del'];
  $st = $mysqli->prepare("SELECT image FROM banners WHERE id=?");
  $st->bind_param('i', $id); $st->execute(); $st->bind_result($img); if ($st->fetch()) {
    @unlink(BASE_PATH.'/uploads/'.$img);
  } $st->close();
  $mysqli->query("DELETE FROM banners WHERE id=".(int)$id);
  header('Location: banner.php'); exit;
}
$rows = $mysqli->query("SELECT id, image, link FROM banners ORDER BY id DESC");
?>
<div class="max-w-3xl">
  <h2 class="text-lg font-semibold mb-3">Manage Banners</h2>
  <?php if ($msg): ?><div class="mb-3 p-2 bg-green-50 border border-green-200 text-green-800 rounded"><?php echo e($msg); ?></div><?php endif; ?>
  <form method="post" enctype="multipart/form-data" class="bg-white border border-slate/20 rounded p-4 space-y-3">
    <input type="hidden" name="csrf" value="<?php echo e(csrf_token()); ?>">
    <div>
      <label class="block text-sm mb-1">Image (16:9)</label>
      <input type="file" name="image" accept=".jpg,.jpeg,.png" required />
    </div>
    <div>
      <label class="block text-sm mb-1">Link (optional)</label>
      <input name="link" class="w-full border rounded px-3 py-2" placeholder="https://..." />
    </div>
    <button class="px-4 py-2 bg-brand text-white rounded">Add Banner</button>
  </form>

  <div class="mt-6 grid grid-cols-2 md:grid-cols-3 gap-3">
    <?php while ($b = $rows->fetch_assoc()): ?>
      <div class="bg-white border border-slate/20 rounded overflow-hidden">
        <img src="<?php echo '../uploads/'.e($b['image']); ?>" alt="" class="w-full aspect-video object-cover">
        <div class="p-2 flex items-center justify-between">
          <a class="text-xs text-brand" href="<?php echo e($b['link']); ?>" target="_blank">Open</a>
          <a class="text-xs text-red-600" href="?del=<?php echo (int)$b['id']; ?>" onclick="return confirm('Delete banner?')">Delete</a>
        </div>
      </div>
    <?php endwhile; ?>
  </div>
</div>
<?php include __DIR__.'/common/footer.php'; ?>
