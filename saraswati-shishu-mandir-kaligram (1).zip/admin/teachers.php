<?php include __DIR__.'/common/header.php'; verify_csrf(); ?>
<?php
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $name = trim($_POST['name'] ?? '');
  $subject = trim($_POST['subject'] ?? '');
  $qualification = trim($_POST['qualification'] ?? '');
  $photo = '';
  if (!empty($_FILES['photo']['name'])) {
    [$ok, $res] = safe_upload($_FILES['photo'], BASE_PATH.'/uploads/gallery', ['jpg','jpeg','png']);
    if ($ok) { $photo = $res; resize_image_if_needed(BASE_PATH.'/uploads/gallery/'.$res); } else { $msg = $res; }
  }
  if (!$msg) {
    $st = $mysqli->prepare("INSERT INTO teachers (name, subject, qualification, photo, created_at) VALUES (?,?,?,?,NOW())");
    $st->bind_param('ssss', $name, $subject, $qualification, $photo);
    $st->execute(); $st->close();
    $msg = 'Teacher added.';
  }
}
if (isset($_GET['del'])) {
  $id = (int)$_GET['del'];
  $st = $mysqli->prepare("SELECT photo FROM teachers WHERE id=?");
  $st->bind_param('i',$id); $st->execute(); $st->bind_result($f);
  if ($st->fetch() && $f) { @unlink(BASE_PATH.'/uploads/gallery/'.$f); }
  $st->close();
  $mysqli->query("DELETE FROM teachers WHERE id={$id}");
  header('Location: teachers.php'); exit;
}
$rows = $mysqli->query("SELECT id, name, subject, qualification FROM teachers ORDER BY created_at DESC");
?>
<div class="max-w-3xl">
  <h2 class="text-lg font-semibold mb-3">Manage Teachers</h2>
  <?php if ($msg): ?><div class="mb-3 p-2 bg-green-50 border border-green-200 text-green-800 rounded"><?php echo e($msg); ?></div><?php endif; ?>
  <form method="post" enctype="multipart/form-data" class="bg-white border border-slate/20 rounded p-4 space-y-3">
    <input type="hidden" name="csrf" value="<?php echo e(csrf_token()); ?>">
    <div class="grid md:grid-cols-2 gap-3">
      <div>
        <label class="block text-sm mb-1">Name</label>
        <input name="name" required class="w-full border rounded px-3 py-2" />
      </div>
      <div>
        <label class="block text-sm mb-1">Subject</label>
        <input name="subject" required class="w-full border rounded px-3 py-2" />
      </div>
    </div>
    <div>
      <label class="block text-sm mb-1">Qualification</label>
      <input name="qualification" class="w-full border rounded px-3 py-2" />
    </div>
    <div>
      <label class="block text-sm mb-1">Photo</label>
      <input type="file" name="photo" accept=".jpg,.jpeg,.png" />
    </div>
    <button class="px-4 py-2 bg-brand text-white rounded">Add Teacher</button>
  </form>

  <div class="mt-6 bg-white border border-slate/20 rounded divide-y">
    <?php while ($t = $rows->fetch_assoc()): ?>
      <div class="p-3 flex items-center justify-between">
        <div>
          <div class="font-medium"><?php echo e($t['name']); ?></div>
          <div class="text-xs opacity-70"><?php echo e($t['subject']); ?> — <?php echo e($t['qualification']); ?></div>
        </div>
        <a class="text-sm text-red-600" href="?del=<?php echo (int)$t['id']; ?>" onclick="return confirm('Delete?')">Delete</a>
      </div>
    <?php endwhile; ?>
  </div>
</div>
<?php include __DIR__.'/common/footer.php'; ?>
