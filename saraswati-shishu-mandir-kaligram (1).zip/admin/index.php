<?php include __DIR__.'/common/header.php'; ?>
<?php
$counts = ['students'=>0,'teachers'=>0,'notices'=>0,'admissions'=>0];
if ($mysqli && !$mysqli->connect_errno) {
  foreach (array_keys($counts) as $t) {
    $r = $mysqli->query("SELECT COUNT(*) c FROM `$t`");
    $counts[$t] = ($r && $row=$r->fetch_assoc()) ? (int)$row['c'] : 0;
  }
}
?>
<div class="grid grid-cols-2 md:grid-cols-4 gap-3">
  <div class="p-4 bg-white border border-slate/20 rounded">
    <div class="text-xs opacity-70">Students</div>
    <div class="text-2xl font-semibold"><?php echo $counts['students']; ?></div>
  </div>
  <div class="p-4 bg-white border border-slate/20 rounded">
    <div class="text-xs opacity-70">Teachers</div>
    <div class="text-2xl font-semibold"><?php echo $counts['teachers']; ?></div>
  </div>
  <div class="p-4 bg-white border border-slate/20 rounded">
    <div class="text-xs opacity-70">Notices</div>
    <div class="text-2xl font-semibold"><?php echo $counts['notices']; ?></div>
  </div>
  <div class="p-4 bg-white border border-slate/20 rounded">
    <div class="text-xs opacity-70">Admissions</div>
    <div class="text-2xl font-semibold"><?php echo $counts['admissions']; ?></div>
  </div>
</div>

<div class="mt-6 grid md:grid-cols-3 gap-3">
  <a href="notice.php" class="p-4 bg-white border border-slate/20 rounded flex items-center justify-between">
    <div><div class="text-sm">Add Notice</div></div><i class="fa fa-plus text-brand"></i>
  </a>
  <a href="results.php" class="p-4 bg-white border border-slate/20 rounded flex items-center justify-between">
    <div><div class="text-sm">Upload Results</div></div><i class="fa fa-upload text-brand"></i>
  </a>
  <a href="events.php" class="p-4 bg-white border border-slate/20 rounded flex items-center justify-between">
    <div><div class="text-sm">Add Event</div></div><i class="fa fa-calendar text-brand"></i>
  </a>
</div>
<?php include __DIR__.'/common/footer.php'; ?>
