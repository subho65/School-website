<?php include __DIR__.'/common/header.php'; ?>
<?php
if (isset($_GET['approve'])) {
  $id=(int)$_GET['approve']; $mysqli->query("UPDATE admissions SET status='approved' WHERE id={$id}");
  header('Location: admissions.php'); exit;
}
if (isset($_GET['reject'])) {
  $id=(int)$_GET['reject']; $mysqli->query("UPDATE admissions SET status='rejected' WHERE id={$id}");
  header('Location: admissions.php'); exit;
}
$rows = $mysqli->query("SELECT * FROM admissions ORDER BY created_at DESC LIMIT 200");
?>
<div class="max-w-6xl">
  <h2 class="text-lg font-semibold mb-3">Online Applications</h2>
  <div class="bg-white border border-slate/20 rounded overflow-x-auto">
    <table class="min-w-full text-sm">
      <thead><tr class="bg-slate/10">
        <th class="text-left p-2">Name</th><th class="text-left p-2">Class</th><th class="text-left p-2">DOB</th>
        <th class="text-left p-2">Parent</th><th class="text-left p-2">Contact</th><th class="text-left p-2">Docs</th><th class="text-left p-2">Status</th><th class="text-left p-2">Actions</th>
      </tr></thead>
      <tbody>
      <?php while ($a = $rows->fetch_assoc()): ?>
        <tr class="border-t">
          <td class="p-2"><?php echo e($a['name']); ?></td>
          <td class="p-2"><?php echo e($a['class_applied']); ?></td>
          <td class="p-2"><?php echo e($a['dob']); ?></td>
          <td class="p-2"><?php echo e($a['parent_name']); ?></td>
          <td class="p-2"><?php echo e($a['email']); ?><br><?php echo e($a['phone']); ?></td>
          <td class="p-2"><?php if ($a['docs']): ?><span class="text-xs">Secured</span><?php endif; ?></td>
          <td class="p-2"><?php echo e($a['status']); ?></td>
          <td class="p-2">
            <a class="text-xs text-green-700" href="?approve=<?php echo (int)$a['id']; ?>">Approve</a> |
            <a class="text-xs text-red-700" href="?reject=<?php echo (int)$a['id']; ?>">Reject</a>
          </td>
        </tr>
      <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>
<?php include __DIR__.'/common/footer.php'; ?>
