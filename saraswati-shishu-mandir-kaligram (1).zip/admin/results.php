<?php include __DIR__.'/common/header.php'; verify_csrf(); ?>
<?php
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['csv'])) {
  if (($handle = fopen($_FILES['csv']['tmp_name'], "r")) !== false) {
    // Expect header: roll_no,class,subject,marks
    $header = fgetcsv($handle);
    $okCount = 0; $skip = 0;
    while (($row = fgetcsv($handle)) !== false) {
      $data = array_combine($header, $row);
      $roll = trim($data['roll_no'] ?? '');
      $class = trim($data['class'] ?? '');
      $subject = trim($data['subject'] ?? '');
      $marks = trim($data['marks'] ?? '');
      if (!$roll || !$subject) { $skip++; continue; }
      $st = $mysqli->prepare("SELECT id FROM students WHERE roll_no = ? LIMIT 1");
      $st->bind_param('s',$roll); $st->execute(); $st->bind_result($sid);
      if ($st->fetch()) {
        $st->close();
        $ins = $mysqli->prepare("INSERT INTO results (student_id, class, subject, marks, created_at) VALUES (?,?,?,?,NOW())");
        $ins->bind_param('isss', $sid, $class, $subject, $marks);
        if ($ins->execute()) $okCount++;
        $ins->close();
      } else { $st->close(); $skip++; }
    }
    fclose($handle);
    $msg = "Imported: {$okCount}, Skipped: {$skip}";
  } else { $msg = 'Failed to read CSV'; }
}
if (isset($_GET['del'])) {
  $id=(int)$_GET['del'];
  $mysqli->query("DELETE FROM results WHERE id={$id}");
  header('Location: results.php'); exit;
}
$rows = $mysqli->query("SELECT r.id, s.name, s.roll_no, r.subject, r.marks FROM results r JOIN students s ON s.id=r.student_id ORDER BY r.id DESC LIMIT 200");
?>
<div class="max-w-4xl">
  <h2 class="text-lg font-semibold mb-3">Upload Results (CSV)</h2>
  <?php if ($msg): ?><div class="mb-3 p-2 bg-green-50 border border-green-200 text-green-800 rounded"><?php echo e($msg); ?></div><?php endif; ?>
  <form method="post" enctype="multipart/form-data" class="bg-white border border-slate/20 rounded p-4 space-y-3">
    <input type="hidden" name="csrf" value="<?php echo e(csrf_token()); ?>">
    <input type="file" name="csv" accept=".csv" required />
    <div class="text-xs opacity-70">Headers: roll_no,class,subject,marks</div>
    <button class="px-4 py-2 bg-brand text-white rounded">Import</button>
  </form>

  <h3 class="mt-6 font-semibold mb-2">Recent Entries</h3>
  <div class="bg-white border border-slate/20 rounded divide-y">
    <?php while ($r = $rows->fetch_assoc()): ?>
      <div class="p-3 flex items-center justify-between">
        <div class="text-sm"><?php echo e($r['name']); ?> (<?php echo e($r['roll_no']); ?>) — <?php echo e($r['subject']); ?>: <span class="font-medium"><?php echo e($r['marks']); ?></span></div>
        <a class="text-xs text-red-600" href="?del=<?php echo (int)$r['id']; ?>" onclick="return confirm('Delete?')">Delete</a>
      </div>
    <?php endwhile; ?>
  </div>
</div>
<?php include __DIR__.'/common/footer.php'; ?>
