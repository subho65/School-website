<?php
require_once __DIR__.'/../common/config.php';
header('Content-Type: application/json; charset=UTF-8');

$input = json_decode(file_get_contents('php://input'), true) ?: [];
$roll = trim($input['roll_no'] ?? '');
$dob = trim($input['dob'] ?? '');

if (!$mysqli || $mysqli->connect_errno) {
  echo json_encode(['ok'=>false,'message'=>'DB unavailable']); exit;
}
if (!$roll || !$dob) { echo json_encode(['ok'=>false,'message'=>'Missing fields']); exit; }

$st = $mysqli->prepare("SELECT id, name, class, roll_no FROM students WHERE roll_no = ? AND dob = ?");
$st->bind_param('ss', $roll, $dob);
$st->execute();
$st->bind_result($sid, $name, $class, $rollno);
if (!$st->fetch()) {
  echo json_encode(['ok'=>false,'message'=>'Student not found']); $st->close(); exit;
}
$st->close();

$rst = $mysqli->prepare("SELECT subject, marks FROM results WHERE student_id = ? ORDER BY subject ASC");
$rst->bind_param('i', $sid);
$rst->execute();
$res = $rst->get_result();
$rows = [];
while ($r = $res->fetch_assoc()) { $rows[] = ['subject'=>$r['subject'],'marks'=>$r['marks']]; }
$rst->close();

echo json_encode(['ok'=>true,'student'=>['id'=>$sid,'name'=>$name,'class'=>$class,'roll_no'=>$rollno],'results'=>$rows]);
